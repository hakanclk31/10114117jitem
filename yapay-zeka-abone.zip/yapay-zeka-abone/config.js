module.exports = {

    token: "", //bot tokeniniz
    clientId: "", //Bot idsi
    key: "", //ocr.space key link : https://ocr.space

    //Alttakileri elleme !
    langs: [
        'Subscribed',
        'Aboneolundu',
        'Abunəoldu',
        'Abone olundu',
        'Abunə oldu',
        'Gezeichnet',
        'Abonné',
        'Εγγεγραμμένος'
    ],
}